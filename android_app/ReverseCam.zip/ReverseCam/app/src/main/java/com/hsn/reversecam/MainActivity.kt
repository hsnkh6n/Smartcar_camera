package com.hsn.reversecam

import android.annotation.SuppressLint
import android.os.Bundle
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.appcompat.app.AppCompatActivity
import android.os.Handler
import android.os.Looper

class MainActivity : AppCompatActivity() {

    private lateinit var webView: WebView

    // Your Pi2 camera stream URL
    private val streamUrl = "http://192.168.10.2:8080/?action=stream"

    private val handler = Handler(Looper.getMainLooper())

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        webView = findViewById(R.id.camWebView)

        val settings: WebSettings = webView.settings
        settings.javaScriptEnabled = true
        settings.loadsImagesAutomatically = true
        settings.domStorageEnabled = true
        settings.useWideViewPort = true
        settings.loadWithOverviewMode = true
        settings.blockNetworkImage = false
        settings.mediaPlaybackRequiresUserGesture = false

        webView.webViewClient = WebViewClient()

        loadCamera()

        // Auto reload every 5 seconds
        handler.postDelayed(object : Runnable {
            override fun run() {
                loadCamera()
                handler.postDelayed(this, 5000)
            }
        }, 5000)
    }

    private fun loadCamera() {
        val html = """
            <html>
            <body style="margin:0;padding:0;background:black;">
                <img src="$streamUrl" style="width:100%;height:100%;object-fit:cover;">
            </body>
            </html>
        """.trimIndent()

        webView.loadDataWithBaseURL(null, html, "text/html", "UTF-8", null)
    }
}
